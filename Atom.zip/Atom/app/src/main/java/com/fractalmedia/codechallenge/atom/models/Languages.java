package com.fractalmedia.codechallenge.atom.models;

public class Languages {

    private String iso;
    private String name;

    public String getIso() {
        return iso;
    }

    public void setIso(String iso) {
        this.iso = iso;
    }
}
