package com.fractalmedia.codechallenge.atom.adapters;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.fractalmedia.codechallenge.atom.R;
import com.fractalmedia.codechallenge.atom.models.Movie;

import java.util.List;

public class MovieAdapter extends RecyclerView.Adapter<MovieAdapter.MyViewHolder>  {

    public List<Movie> mMovieList;


    public MovieAdapter(List<Movie> movies){
        mMovieList = movies;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_main, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        holder.tvTitle.setText(mMovieList.get(position).getTitle());
        holder.tvDesc.setText(mMovieList.get(position).getDescription());
        //TODO: Cargar imagen por url utilizando Picasso

    }

    @Override
    public int getItemCount() {
        return mMovieList == null ? 0 : mMovieList.size();
    }

    public static class MyViewHolder  extends RecyclerView.ViewHolder{

        public ImageView ivMovie;
        public TextView tvTitle;
        public TextView tvDesc;


        public MyViewHolder(final View itemView){
            super(itemView);
            this.ivMovie = itemView.findViewById(R.id.ivMovie);
            this.tvTitle = itemView.findViewById(R.id.tvTitle);
            this.tvDesc = itemView.findViewById(R.id.tvDesc);
        }
    }
}
