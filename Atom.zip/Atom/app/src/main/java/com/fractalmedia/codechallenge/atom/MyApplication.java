package com.fractalmedia.codechallenge.atom;

import android.text.NoCopySpan;

public class MyApplication extends android.app.Application {


    @Override
    public void onCreate() {
        super.onCreate();
    }
}
